#include "library.h"
#include <math.h>

float f(float x){
    float y;
    // y = cos(x);
    y = x*x;
    return y;
}