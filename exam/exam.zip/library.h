#ifndef LIBRARY_H
#define LIBRARY_H

#ifdef __cplusplus
extern "C"{
#endif /*__cplusplus*/

float f(float x);

#ifdef __cplusplus
} /*extern "C" */
#endif /*__cplusplus*/
#endif /*LIBRARY_H*/

