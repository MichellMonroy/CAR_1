 
#include "Timming.h"

void uswtime(double *usertime, double *systime, double *walltime)
{
double mega = 1.0e-6;
struct rusage buffer;
struct timeval tp;
struct timezone tzp;

getrusage(RUSAGE_SELF, &buffer);
gettimeofday(&tp, &tzp);
*usertime = (double) buffer.ru_utime.tv_sec +
              1.0e-6 * buffer.ru_utime.tv_usec;
*systime  = (double) buffer.ru_stime.tv_sec +
              1.0e-6 * buffer.ru_stime.tv_usec;
*walltime = (double) tp.tv_sec + 1.0e-6 * tp.tv_usec;
} 